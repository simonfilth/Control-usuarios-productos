<?php

return array(	
	'user-search' => [
		// ''	       => 'Búsqueda por',
		'name'	   => 'Nombre',
		'username' => 'Usuario',
		'email'    => 'Email',
		'tipousuarioid'    => 'Tipo de Usuario'
	],

	'productos-search' => [
		'nombre' => 'Nombre', 
	    'codigo' => 'Código',
	    'descripcion' => 'Descripcion',
	    'precio' => 'Precio',
	    'cantidad' => 'Cantidad'
	],

	'categoria' => [
		'1' => "Bebidas",
		'2' => "Carnes",
		'3' => "Condimentos",
		'4' => "Frutas",
		'5' => "Lácteos",
		'6' => "Pescado",
		'7' => "Harinas",
		'8' => "Repostería"
	]

);