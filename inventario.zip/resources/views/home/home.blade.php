
@extends('layouts.home')

@section('content')
<h1>Bienvenid@s a la aplicación prueba de Control de usuarios y productos</h1>
@stop
